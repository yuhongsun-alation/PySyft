syft.core.node.device.device\_type package
==========================================

.. automodule:: syft.core.node.device.device_type
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   syft.core.node.device.device_type.specs

Submodules
----------

syft.core.node.device.device\_type.device\_type module
------------------------------------------------------

.. automodule:: syft.core.node.device.device_type.device_type
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device\_type.unknown module
-------------------------------------------------

.. automodule:: syft.core.node.device.device_type.unknown
   :members:
   :undoc-members:
   :show-inheritance:
