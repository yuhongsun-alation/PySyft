syft package
============

.. automodule:: syft
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   syft.ast
   syft.core
   syft.decorators
   syft.grid
   syft.lib

Submodules
----------

syft.util module
----------------

.. automodule:: syft.util
   :members:
   :undoc-members:
   :show-inheritance:
