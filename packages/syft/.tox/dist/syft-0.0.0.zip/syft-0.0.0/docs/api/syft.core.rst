syft.core package
=================

.. automodule:: syft.core
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   syft.core.common
   syft.core.io
   syft.core.node
   syft.core.pointer
   syft.core.store
