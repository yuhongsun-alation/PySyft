syft.core.node.device.device\_type.specs package
================================================

.. automodule:: syft.core.node.device.device_type.specs
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

syft.core.node.device.device\_type.specs.cpu module
---------------------------------------------------

.. automodule:: syft.core.node.device.device_type.specs.cpu
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device\_type.specs.gpu module
---------------------------------------------------

.. automodule:: syft.core.node.device.device_type.specs.gpu
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device\_type.specs.network module
-------------------------------------------------------

.. automodule:: syft.core.node.device.device_type.specs.network
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device\_type.specs.provider module
--------------------------------------------------------

.. automodule:: syft.core.node.device.device_type.specs.provider
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device\_type.specs.storage module
-------------------------------------------------------

.. automodule:: syft.core.node.device.device_type.specs.storage
   :members:
   :undoc-members:
   :show-inheritance:
