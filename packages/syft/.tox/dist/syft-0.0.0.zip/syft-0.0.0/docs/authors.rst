.. _authors:
.. include:: ../AUTHORS.rst
