# stdlib
from typing import Any as TypeAny
from typing import Dict as TypeDict

JSONDict = TypeDict[str, TypeAny]  # noqa: 401
