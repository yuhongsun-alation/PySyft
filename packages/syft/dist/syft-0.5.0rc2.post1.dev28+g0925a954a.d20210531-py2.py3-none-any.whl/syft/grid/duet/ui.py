# stdlib
import os
from pathlib import Path

LOGO_URL = os.path.abspath(Path(__file__) / "../../../img/logo_duet.png")
