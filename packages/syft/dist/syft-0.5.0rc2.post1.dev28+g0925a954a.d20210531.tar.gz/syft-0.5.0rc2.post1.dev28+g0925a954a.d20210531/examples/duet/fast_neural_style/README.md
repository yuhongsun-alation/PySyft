# fast_neural_style :city_sunrise: :rocket:
