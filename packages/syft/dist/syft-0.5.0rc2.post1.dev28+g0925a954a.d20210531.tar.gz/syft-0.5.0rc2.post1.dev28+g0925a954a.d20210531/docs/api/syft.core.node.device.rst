syft.core.node.device package
=============================

.. automodule:: syft.core.node.device
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   syft.core.node.device.device_type

Submodules
----------

syft.core.node.device.client module
-----------------------------------

.. automodule:: syft.core.node.device.client
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.node.device.device module
-----------------------------------

.. automodule:: syft.core.node.device.device
   :members:
   :undoc-members:
   :show-inheritance:
