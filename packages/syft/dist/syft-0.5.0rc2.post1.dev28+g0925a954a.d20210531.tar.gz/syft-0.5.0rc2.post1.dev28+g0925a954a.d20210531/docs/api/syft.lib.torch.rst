syft.lib.torch package
======================

.. automodule:: syft.lib.torch
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

syft.lib.torch.allowlist module
-------------------------------

.. automodule:: syft.lib.torch.allowlist
   :members:
   :undoc-members:
   :show-inheritance:

syft.lib.torch.module module
----------------------------

.. automodule:: syft.lib.torch.module
   :members:
   :undoc-members:
   :show-inheritance:

syft.lib.torch.parameter module
-------------------------------

.. automodule:: syft.lib.torch.parameter
   :members:
   :undoc-members:
   :show-inheritance:

syft.lib.torch.tensor\_util module
----------------------------------

.. automodule:: syft.lib.torch.tensor_util
   :members:
   :undoc-members:
   :show-inheritance:

syft.lib.torch.uppercase\_tensor module
---------------------------------------

.. automodule:: syft.lib.torch.uppercase_tensor
   :members:
   :undoc-members:
   :show-inheritance:
