syft.core.common.serde package
==============================

.. automodule:: syft.core.common.serde
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

syft.core.common.serde.deserialize module
-----------------------------------------

.. automodule:: syft.core.common.serde.deserialize
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.common.serde.serializable module
------------------------------------------

.. automodule:: syft.core.common.serde.serializable
   :members:
   :undoc-members:
   :show-inheritance:

syft.core.common.serde.serialize module
---------------------------------------

.. automodule:: syft.core.common.serde.serialize
   :members:
   :undoc-members:
   :show-inheritance:
